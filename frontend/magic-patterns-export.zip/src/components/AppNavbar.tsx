import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  SparklesIcon,
  MenuIcon,
  XIcon,
  UserIcon,
  SettingsIcon,
  LogOutIcon,
  ChevronDownIcon,
  TrendingUpIcon,
  HeartIcon,
  GemIcon,
  UsersIcon,
  CalendarIcon,
  StarIcon } from
'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useAIChat } from '../contexts/AIChatContext';
export function AppNavbar() {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const { openChat } = useAIChat();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isMoreOpen, setIsMoreOpen] = useState(false);
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  const moreTools = [
  {
    label: 'Life Path Analysis',
    path: '/life-path',
    icon: <TrendingUpIcon className="w-4 h-4" />
  },
  {
    label: 'Birth Chart',
    path: '/birth-chart',
    icon: <StarIcon className="w-4 h-4" />
  },
  {
    label: 'Compatibility',
    path: '/compatibility',
    icon: <HeartIcon className="w-4 h-4" />
  },
  {
    label: 'Remedies',
    path: '/remedies',
    icon: <GemIcon className="w-4 h-4" />
  },
  {
    label: 'Consultations',
    path: '/consultations',
    icon: <UsersIcon className="w-4 h-4" />
  },
  {
    label: 'Forecasts',
    path: '/forecasts',
    icon: <CalendarIcon className="w-4 h-4" />
  }];

  return (
    <>
      <motion.nav
        initial={{
          y: -100,
          opacity: 0
        }}
        animate={{
          y: 0,
          opacity: 1
        }}
        className="fixed top-0 left-0 right-0 z-50 px-4 sm:px-6 py-4">

        <div className="max-w-7xl mx-auto">
          <div className="bg-[#1a2942]/60 backdrop-blur-2xl rounded-3xl border border-cyan-500/20 shadow-xl shadow-cyan-500/10 px-4 sm:px-6 py-3">
            <div className="flex items-center justify-between">
              {/* Logo */}
              <motion.button
                onClick={() => navigate('/dashboard')}
                className="flex items-center gap-2 group"
                whileHover={{
                  scale: 1.05
                }}
                whileTap={{
                  scale: 0.95
                }}>

                <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/30">
                  <SparklesIcon className="w-6 h-6 text-white" />
                </div>
                <span className="text-xl font-bold font-['Playfair_Display'] text-white hidden sm:inline">
                  NumerAI
                </span>
              </motion.button>

              {/* Desktop Navigation */}
              <div className="hidden md:flex items-center gap-6">
                <motion.button
                  onClick={() => navigate('/dashboard')}
                  className="text-white/80 hover:text-cyan-400 font-medium transition-colors"
                  whileHover={{
                    y: -2
                  }}>

                  Dashboard
                </motion.button>
                <motion.button
                  onClick={() => navigate('/report')}
                  className="text-white/80 hover:text-cyan-400 font-medium transition-colors"
                  whileHover={{
                    y: -2
                  }}>

                  Reports
                </motion.button>
                <motion.button
                  onClick={openChat}
                  className="text-white/80 hover:text-cyan-400 font-medium transition-colors"
                  whileHover={{
                    y: -2
                  }}>

                  Chat
                </motion.button>
                <motion.button
                  onClick={() => navigate('/daily-readings')}
                  className="text-white/80 hover:text-cyan-400 font-medium transition-colors"
                  whileHover={{
                    y: -2
                  }}>

                  Readings
                </motion.button>

                {/* More Tools Dropdown */}
                <div className="relative">
                  <motion.button
                    onClick={() => setIsMoreOpen(!isMoreOpen)}
                    className="flex items-center gap-1 text-white/80 hover:text-cyan-400 font-medium transition-colors"
                    whileHover={{
                      y: -2
                    }}>

                    More
                    <ChevronDownIcon className="w-4 h-4" />
                  </motion.button>

                  <AnimatePresence>
                    {isMoreOpen &&
                    <>
                        <div
                        className="fixed inset-0 z-40"
                        onClick={() => setIsMoreOpen(false)} />

                        <motion.div
                        initial={{
                          opacity: 0,
                          y: 10,
                          scale: 0.95
                        }}
                        animate={{
                          opacity: 1,
                          y: 0,
                          scale: 1
                        }}
                        exit={{
                          opacity: 0,
                          y: 10,
                          scale: 0.95
                        }}
                        transition={{
                          duration: 0.2
                        }}
                        className="absolute right-0 mt-2 w-56 bg-[#1a2942]/95 backdrop-blur-xl rounded-2xl border border-cyan-500/20 shadow-xl overflow-hidden z-50">

                          {moreTools.map((tool) =>
                        <button
                          key={tool.path}
                          onClick={() => {
                            navigate(tool.path);
                            setIsMoreOpen(false);
                          }}
                          className="w-full px-4 py-3 text-left text-white hover:bg-cyan-500/10 transition-colors flex items-center gap-3">

                              {tool.icon}
                              <span className="text-sm">{tool.label}</span>
                            </button>
                        )}
                        </motion.div>
                      </>
                    }
                  </AnimatePresence>
                </div>
              </div>

              {/* Right Side Actions */}
              <div className="flex items-center gap-3">
                {/* Profile Dropdown */}
                <div className="hidden md:block relative">
                  <motion.button
                    onClick={() => setIsProfileOpen(!isProfileOpen)}
                    className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/30"
                    whileHover={{
                      scale: 1.1
                    }}
                    whileTap={{
                      scale: 0.95
                    }}
                    aria-label="User profile menu">

                    <UserIcon className="w-5 h-5 text-white" />
                  </motion.button>

                  <AnimatePresence>
                    {isProfileOpen &&
                    <>
                        <div
                        className="fixed inset-0 z-40"
                        onClick={() => setIsProfileOpen(false)} />

                        <motion.div
                        initial={{
                          opacity: 0,
                          y: 10,
                          scale: 0.95
                        }}
                        animate={{
                          opacity: 1,
                          y: 0,
                          scale: 1
                        }}
                        exit={{
                          opacity: 0,
                          y: 10,
                          scale: 0.95
                        }}
                        transition={{
                          duration: 0.2
                        }}
                        className="absolute right-0 mt-2 w-48 bg-[#1a2942]/95 backdrop-blur-xl rounded-2xl border border-cyan-500/20 shadow-xl overflow-hidden z-50">

                          <button
                          onClick={() => {
                            navigate('/settings');
                            setIsProfileOpen(false);
                          }}
                          className="w-full px-4 py-3 text-left text-white hover:bg-cyan-500/10 transition-colors flex items-center gap-2">

                            <SettingsIcon className="w-4 h-4" />
                            Settings
                          </button>
                          <button
                          onClick={handleLogout}
                          className="w-full px-4 py-3 text-left text-white hover:bg-cyan-500/10 transition-colors flex items-center gap-2">

                            <LogOutIcon className="w-4 h-4" />
                            Logout
                          </button>
                        </motion.div>
                      </>
                    }
                  </AnimatePresence>
                </div>

                {/* Mobile Menu Button */}
                <motion.button
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="md:hidden p-2 rounded-xl bg-[#1a2942]/60 backdrop-blur-xl border border-cyan-500/20"
                  whileHover={{
                    scale: 1.1
                  }}
                  whileTap={{
                    scale: 0.95
                  }}
                  aria-label="Toggle mobile menu">

                  {isMenuOpen ?
                  <XIcon className="w-6 h-6 text-white" /> :

                  <MenuIcon className="w-6 h-6 text-white" />
                  }
                </motion.button>
              </div>
            </div>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen &&
        <>
            <motion.div
            initial={{
              opacity: 0
            }}
            animate={{
              opacity: 1
            }}
            exit={{
              opacity: 0
            }}
            onClick={() => setIsMenuOpen(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden" />


            <motion.div
            initial={{
              opacity: 0,
              y: -20
            }}
            animate={{
              opacity: 1,
              y: 0
            }}
            exit={{
              opacity: 0,
              y: -20
            }}
            transition={{
              type: 'spring',
              damping: 25,
              stiffness: 300
            }}
            className="fixed top-20 left-4 right-4 z-50 md:hidden">

              <div className="bg-[#1a2942]/95 backdrop-blur-xl rounded-2xl border border-cyan-500/20 shadow-2xl overflow-hidden">
                <div className="p-4 space-y-2">
                  <button
                  onClick={() => {
                    navigate('/dashboard');
                    setIsMenuOpen(false);
                  }}
                  className="w-full px-4 py-3 text-left text-white hover:bg-cyan-500/10 rounded-xl transition-colors font-medium">

                    Dashboard
                  </button>
                  <button
                  onClick={() => {
                    navigate('/report');
                    setIsMenuOpen(false);
                  }}
                  className="w-full px-4 py-3 text-left text-white hover:bg-cyan-500/10 rounded-xl transition-colors font-medium">

                    Reports
                  </button>
                  <button
                  onClick={() => {
                    openChat();
                    setIsMenuOpen(false);
                  }}
                  className="w-full px-4 py-3 text-left text-white hover:bg-cyan-500/10 rounded-xl transition-colors font-medium">

                    Chat
                  </button>
                  <button
                  onClick={() => {
                    navigate('/daily-readings');
                    setIsMenuOpen(false);
                  }}
                  className="w-full px-4 py-3 text-left text-white hover:bg-cyan-500/10 rounded-xl transition-colors font-medium">

                    Readings
                  </button>

                  {/* More Tools in Mobile */}
                  <div className="border-t border-cyan-500/20 pt-2 mt-2">
                    <p className="px-4 py-2 text-xs text-white/60 font-semibold uppercase">
                      More Tools
                    </p>
                    {moreTools.map((tool) =>
                  <button
                    key={tool.path}
                    onClick={() => {
                      navigate(tool.path);
                      setIsMenuOpen(false);
                    }}
                    className="w-full px-4 py-3 text-left text-white hover:bg-cyan-500/10 rounded-xl transition-colors flex items-center gap-3">

                        {tool.icon}
                        <span className="text-sm">{tool.label}</span>
                      </button>
                  )}
                  </div>

                  <div className="border-t border-cyan-500/20 pt-2">
                    <button
                    onClick={() => {
                      navigate('/settings');
                      setIsMenuOpen(false);
                    }}
                    className="w-full px-4 py-3 text-left text-white hover:bg-cyan-500/10 rounded-xl transition-colors flex items-center gap-2 font-medium">

                      <SettingsIcon className="w-4 h-4" />
                      Settings
                    </button>
                    <button
                    onClick={handleLogout}
                    className="w-full px-4 py-3 text-left text-white hover:bg-cyan-500/10 rounded-xl transition-colors flex items-center gap-2 font-medium">

                      <LogOutIcon className="w-4 h-4" />
                      Logout
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        }
      </AnimatePresence>
    </>);

}